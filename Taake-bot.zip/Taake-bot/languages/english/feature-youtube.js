exports.translations = {
	commands: {
		/*
		* Youtube Commands
		*/
		youtube: {
			'notchat': 'This command is only available for chat rooms',
			'u': 'Usage',
			'ae': 'YouTube link recognition is already enabled for room',
			'e': 'YouTube link recognition is now enabled for this room',
			'ad': 'YouTube link recognition is already disabled for room',
			'd': 'YouTube link recognition is now disabled for this room'
		}
	},

	youtube: {
		'before': '',
		'after': '\'s link'
	}
};
