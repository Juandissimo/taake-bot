Bot Languages
====================

Each language is a folder. In order to add languages, copy `english` to `[new lang]` and translate the files.

Languages feature is developed to allow bot (commands and features) working in different languages for each room.

**WARNING: Languages consume a lot of memory, remove the languages you don't need if you have important memory restrictions**
