Data Files
====================

Bot data is stored here. Data format is primary `json` or dowloaded `js` files.
