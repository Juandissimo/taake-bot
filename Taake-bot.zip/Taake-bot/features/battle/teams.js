/*
	Bot teams
*/

exports.teams = {
	"uu": [
	'Glalie||Glalitite||frustration,explosion,freeze-dry,hidden power [fire]|Jolly|0,252,4,0,0,252|||||]Chesnaught||leftovers||spikes,taunt,leech seed,drain punch|Impish|252,0,84,0,0,172|||||]Tentacruel||Black Sludge||scald,rapid spin,acid spray,toxic spikes|Timid|248,0,216,0,28,16|||||]Infernape||Rocky helmet||stealth rock,will-o-wisp,slack off,fire punch|impish|248,0,216,0,0,44|||||]Spiritomb||Assault Vest||sucker punch,foul play,pursuit,icy wind|brave|248,252,8,0,0,0|||||]Crobat||choice band||brave bird,defog,zen headbutt,u-turn|jolly|0,252,0,0,4,252|||||'
	],	
	"ou": [
	'Heracross||Heracronite||swords dance,close combat,bullet seed,rock blast|Adamant|248,252,8,0,0,0|||||]Heatran||Leftovers||magma storm,earth power,toxic,taunt|timid|0,0,0,252,4,252|||||]Ferrothorn||leftovers||stealth rock,leech seed,gyro ball,thunder wave|Sassy|248,0,96,0,164,0|||||]Rotom-wash||leftovers||volt switch,hydro pump,will-o-wisp,pain split|bold|248,0,252,0,0,8|||||]Zapdos||life orb||thunderbolt,heat wave,hidden power [ice],roost|timid|0,0,0,252,4,242|||||]starmie||leftovers||scald,rapid spin,recover,psyshock|timid|252,0,0,4,0,252|||||'
	],
	"cap": [
	'plasmanta||black sludge||parabolic charge,sludge bomb,dazzling gleam,psychic|timid|248,0,0,8,0,252|||||]cawmodore||sitrus berry||acrobatics,belly drum,drain punch,bullet punch|jolly|4,252,0,0,0,252|||||]syclant||expert belt||ice punch,earthquake,u-turn,rock slide|jolly|0,252,4,0,0,252|||||]tomohawk||leftovers||stealth rock,roost,air slash,aura sphere|modest|0,0,252,4,252,0|||||]volkraken||leftovers||flamethrower,surf,power gem,will-o-wisp|timid|0,0,0,252,4,252|||||]necturna||leftovers||horn leech,toxic,protect,sticky web|adamant|248,0,132,0,128,0|||||'
	]
};


