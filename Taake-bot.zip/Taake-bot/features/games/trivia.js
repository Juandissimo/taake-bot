/*
	Trivia
*/

var Trivia = require('./constructors.js').Trivia;
var RandomGenerator = require('./trivia-rand.js');

function send (room, str) {
	Bot.say(room, str);
}

function trans (data, room) {
	var lang = Config.language || 'english';
	if (Settings.settings['language'] && Settings.settings['language'][room]) lang = Settings.settings['language'][room];
	return Tools.translateGlobal('games', 'trivia', lang)[data];
}

function parseWinners (winners, room) {
	var res = {
		type: 'win',
		text: "**" + winners[0] + "**"
	};
	if (winners.length < 2) return res;
	res.type = 'tie';
	for (var i = 1; i < winners.length - 1; i++) {
		res.text += ", **" + winners[i] + "**";
	}
	res.text += " " + trans('and', room) + " **" + winners[winners.length - 1] + "**";
	return res;
}

exports.id = 'trivia';

exports.title = 'Trivia';

exports.aliases = [];

var parser = function (type, data) {
	var txt;
	switch (type) {
		case 'start':
			txt = trans('start', this.room);
			if (this.maxGames) txt += ". " + trans('maxgames1', this.room) + " __" + this.maxGames + " " + trans('maxgames2', this.room) + "__";
			if (this.maxPoints) txt += ". " + trans('maxpoints1', this.room) + " __" + this.maxPoints + " " + trans('maxpoints2', this.room) + "__";
			txt += ". " + trans('timer1', this.room) + " __" + Math.floor(this.answerTime / 1000).toString() + " " + trans('timer2', this.room) + "__";
			txt += ". " + trans('help', this.room).replace("$TOKEN", CommandParser.commandTokens[0]);
			send(this.room, txt);
			break;
		case 'show':
			send(this.room, "**" + exports.title + ":** " + this.clue);
			break;
		case 'point':
			send(this.room, trans('correct', this.room) + "! **" + data.user + "** " + trans('point1', this.room) + ": __" + data.word + "__. " + trans('point2', this.room) + ": " + data.points + " " + trans('points', this.room));
			break;
		case 'timeout':
			send(this.room, trans('timeout', this.room) + " " + (this.validAnswers.length === 1 ? trans('timeout2', this.room) : trans('timeout3', this.room)) + " __" + this.validAnswers.join(', ') + "__");
			break;
		case 'end':
			send(this.room, trans('lose', this.room));
			break;
		case 'win':
			txt = "**" + trans('end', this.room) + "** ";
			var t = parseWinners(data.winners, this.room);
			switch (t.type) {
				case 'win':
					txt += trans('grats1', this.room) + " " + t.text + " " + trans('grats2', this.room) + " __" + data.points + " " + trans('points', this.room) + "__!";
					break;
				case 'tie':
					txt += trans('tie1', this.room) + " __" + data.points + " " + trans('points', this.room) + "__ " + trans('tie2', this.room) + " " + t.text;
					break;
			}
			send(this.room, txt);
			break;
		case 'forceend':
			send(this.room, trans('forceend1', this.room) + (this.status === 2 ? (" " + trans('forceend2', this.room) + ": __" + this.validAnswers.join(', ') + "__") : ''));
			break;
		case 'error':
			send(this.room, "**" + exports.title + ": Error (could not fetch a word)");
			this.end(true);
			break;
	}
	if (type in {win: 1, end: 1, forceend: 1}) {
		Features.games.deleteGame(this.room);
	}
};

var wordGenerator = function (arr) {
	return RandomGenerator.randomNoRepeat(arr);
};

exports.newGame = function (room, opts) {
	if (!RandomGenerator.random()) return null;
	var generatorOpts = {
		room: room,
		title: exports.title,
		maxGames: 5,
		maxPoints: 0,
		waitTime: 2 * 1000,
		answerTime: 30 * 1000,
		wordGenerator: wordGenerator
	};
	var temp;
	for (var i in opts) {
		switch (i) {
			case 'ngames':
			case 'maxgames':
			case 'games':
				temp = parseInt(opts[i]) || 0;
				if (temp && temp < 0) return "games ( >= 0 ), maxpoints, time";
				generatorOpts.maxGames = temp;
				break;
			case 'points':
			case 'maxpoints':
				temp = parseInt(opts[i]) || 0;
				if (temp && temp < 0) return "games, maxpoints ( >= 0 ), time";
				generatorOpts.maxPoints = temp;
				break;
			case 'answertime':
			case 'anstime':
			case 'time':
				temp = parseFloat(opts[i]) || 0;
				if (temp) temp *= 1000;
				if (temp && temp < (5 * 1000)) return "games, maxpoints, time ( seconds, >= 5 )";
				generatorOpts.answerTime = temp;
				break;
			default:
				return "games, maxpoints, time";
		}
	}
	if (!generatorOpts.maxGames && !generatorOpts.maxPoints) generatorOpts.maxGames = 5;
	var game = new Trivia(generatorOpts, parser);
	if (!game) return null;
	game.generator = exports.id;
	return game;
};

exports.commands = {
	gword: 'g',
	guess: 'g',
	ta: 'g',
	answer: 'g',
	triviaanswer: 'g',
	g: function (arg, by, room, cmd, game) {
		game.guess(by.substr(1), arg);
	},
	view: function (arg, by, room, cmd, game) {
		if (game.status < 2) return;
		this.restrictReply("**" + exports.title + ":** " + game.clue, 'games');
	},
	end: 'endtrivia',
	endtrivia: function (arg, by, room, cmd, game) {
		if (!this.can('games')) return;
		game.end(true);
	}
};
